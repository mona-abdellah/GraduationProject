<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'src/Exception.php';
require 'src/PHPMailer.php';
require 'src/SMTP.php';

// $usertoken = $_POST["usertoken"];
// $usertoken = 123;
// $apisrc= "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . $usertoken ;

$name = $_GET['name'];
$email = $_GET['email'];
$ph = $_GET['ph'];
$country = $_GET['country'];

$mail = new PHPMailer;
$mail->isSMTP(); 
$mail->SMTPDebug = 2; // 0 = off (for production use) - 1 = client messages - 2 = client and server messages
$mail->Host = "smtp.gmail.com"; // use $mail->Host = gethostbyname('smtp.gmail.com'); // if your network does not support SMTP over IPv6
$mail->Port = 587; // TLS only
$mail->SMTPSecure = 'tls'; // ssl is depracated
$mail->SMTPAuth = true;
$mail->Username = "";
$mail->Password = "";

$mail->setFrom("almeldingroub@gmail.com");
$mail->addAddress("ahhmedabubakr1482@gmail.com");
$mail->addAddress('ayamohsen223300@gmail.com', 'aya mohsen');     //Add a recipient
$mail->Subject = 'subscribe';
// $mail->addAttachment('https://api.qrserver.com/v1/create-qr-code/?size=200x200&data= '. $usertoken);         //Add attachments

// $mail->msgHTML("test body"); //$mail->msgHTML(file_get_contents('contents.html'), __DIR__); //Read an HTML message body from an external file, convert referenced images to embedded,
$mail->isHTML(true);
$mail->Body = '<div style="text-align:left;directio:ltr" > <b>new subscribe MR ibrahem</b> <br> <b>the name is</b>: '. $name .' <br> <b>the email is</b>: '. $email .'<br> <b>the phone is:</b> '. $ph .' <br> <b>the country is:</b> '. $country .'</div> ';
// $mail->addAttachment('TIEClogoHP.png'); //Attach an image file
header("Location:done.php");
if(!$mail->send()){
    echo "Mailer Error: " . $mail->ErrorInfo;
}else{
    echo "Message sent!";
}